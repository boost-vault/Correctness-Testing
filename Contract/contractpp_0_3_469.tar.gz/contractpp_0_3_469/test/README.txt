Programs to test the library correct implementation.

