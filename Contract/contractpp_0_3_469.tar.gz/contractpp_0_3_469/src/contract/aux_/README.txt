Library PRIVATE API.

Do NOT directly use any of the code from files in this directory or
any of the subdirectories.
