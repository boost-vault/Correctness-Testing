Support for implementing contract classes.
