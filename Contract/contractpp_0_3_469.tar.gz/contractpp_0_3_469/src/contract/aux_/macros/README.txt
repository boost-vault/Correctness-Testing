Support for contract macros.
