Code generation.
