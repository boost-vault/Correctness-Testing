Preprocessor signature.
