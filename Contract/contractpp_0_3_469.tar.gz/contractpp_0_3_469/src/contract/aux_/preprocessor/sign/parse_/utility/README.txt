Utilities for preprocessor signature parsing.
