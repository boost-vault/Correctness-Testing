Preprocessor signature parsing.
