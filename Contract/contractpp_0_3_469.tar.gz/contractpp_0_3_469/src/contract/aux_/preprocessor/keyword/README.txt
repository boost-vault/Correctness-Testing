Preprocessor macros to check if token is a keyword.
