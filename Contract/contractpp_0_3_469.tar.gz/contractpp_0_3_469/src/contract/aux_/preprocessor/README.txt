Preprocessor tools internally used by the library.
