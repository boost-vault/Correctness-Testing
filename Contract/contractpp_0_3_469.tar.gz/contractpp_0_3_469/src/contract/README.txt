Library public API.
