The library documentation.
