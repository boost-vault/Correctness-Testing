Examples taken from Crowl, Ottosen, "Proposal to add Contract
Programming to C++", 2006.
