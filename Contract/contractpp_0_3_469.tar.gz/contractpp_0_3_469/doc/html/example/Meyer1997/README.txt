Examples taken from Meyer, "Object Oriented Software Construction",
1997.
