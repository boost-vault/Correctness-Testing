Show how to configure the library to throw on contract failure
instead of terminating (used by documentation).
