This is the main example used in the library documentation.
