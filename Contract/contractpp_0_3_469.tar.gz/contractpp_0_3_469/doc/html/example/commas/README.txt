Show how to pass commas within macro parameters (used by documentation).
