Examples that illustrate how to use the library to write contracts.

Many of these examples are taken from books and articles. The
directory names reflect the example source -- see the library
documentation for a complete reference list.

