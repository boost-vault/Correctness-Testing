Examples taken from Mitchell, McKim, "Design by Contract,
by Example", 2002.
