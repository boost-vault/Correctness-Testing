Examples taken from B. Stroustrup. "The C++ Programming Language", 1997.
