Library documentation source files (in Boost.Quickbook format).
