Pieces of C++ code used by the documentation and that cannot be compiled.
If the code can be comipled, then put it into "example/" instead.
