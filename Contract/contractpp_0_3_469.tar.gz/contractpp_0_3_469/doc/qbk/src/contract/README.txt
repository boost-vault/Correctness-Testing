Documentation of library public API source code.
