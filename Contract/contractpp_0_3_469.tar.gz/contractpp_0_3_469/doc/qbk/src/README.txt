Library source code documentation (Doxygen integrating in Boost.QuickBook).
